File Transfer App - Linux Version
=================================

REQUIREMENTS:
- Python 3.6 or higher
- pip3

HOW TO RUN:
-----------
chmod +x run.sh
./run.sh

OR manually:
pip3 install flask
python3 file_transfer_app.py

